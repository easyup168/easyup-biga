# EasyUp BigA 飞书集成功能技术设计

> Status: Draft  
> Scope: Feishu MVP / Operational Interface / Phase 2.5  
> Project: `easyup168/easyup-biga`  
> Last Updated: 2026-09-21

---

# 1. 文档目的

本文档定义 EasyUp BigA 与飞书（Feishu）集成的第一阶段技术设计。

本功能的目标不是给 BigA 增加新的“决策能力”，而是为当前已经成形的多 Agent 决策系统增加一个真实、低摩擦的运行入口和通知出口。

核心目的：

```text
真实触发
    ↓
真实运行
    ↓
真实通知
    ↓
真实使用
    ↓
真实暴露问题
```

飞书在 BigA 中的定位应是：

> **Operational Interface / Notification Adapter**

而不是：

```text
新的 Specialist
新的 Evidence Source
新的 Decision Engine
```

飞书不参与 Market / Sector / News / Technical / Emotion / Risk 的判断。

---

# 2. 为什么现在适合接飞书

BigA 当前已经具备：

```text
Supervisor
├── Market
├── Emotion
├── Sector
├── News
├── Technical
└── Risk

        ↓

DecisionCard
        ↓
Store / Replay
```

系统当前真正需要验证的是：

```text
连续运行
Decision Identity
Evidence Identity
Temporal Semantics
Provider Reliability
Agent Reliability
Latency
UNKNOWN
Replay
```

如果仍然主要通过：

```text
手工命令
SSH
CLI
SQLite
日志
```

观察系统，则真实使用频率较低，很多异常不容易第一时间暴露。

接入飞书后：

```text
BigA
  ↓
DecisionCard
  ↓
Feishu
  ↓
手机
```

可以显著增加真实运行频率。

因此飞书的价值不是 UI，而是：

> **帮助 BigA 进入 Operational Validation 阶段。**

---

# 3. MVP 目标

Feishu MVP 只实现四个 Story。

## F1 — DecisionCard 推送

当 BigA 完成一次 Decision 后：

```text
DecisionCard
    ↓
Feishu Adapter
    ↓
飞书消息 / 卡片
```

用户可以在手机上直接看到结果。

---

## F2 — Failure / UNKNOWN 通知

当出现：

```text
Agent failed
Provider timeout
UNKNOWN
Missing
Risk BLOCK
Runtime spawn failed
```

时主动发飞书通知。

---

## F3 — 手动触发 BigA

用户可以在飞书中发送简单命令，例如：

```text
/biga market
```

或者：

```text
/biga 600519
```

飞书事件进入 BigA Trigger Adapter：

```text
Feishu
   ↓
Inbound Adapter
   ↓
BigA Runner
   ↓
Decision ID
   ↓
Pipeline
```

---

## F4 — Decision 状态查询

支持：

```text
/biga status BIGA-20260921-001
```

返回：

```text
RUNNING
COMPLETED
FAILED
UNKNOWN
```

以及基本执行状态。

---

# 4. 非目标

MVP 明确不做：

```text
多用户权限系统
复杂 RBAC
审批流
多维表格同步
飞书云文档同步
复杂群聊上下文
持续对话记忆
自然语言自由 Agent 控制
复杂交互卡片
按钮驱动交易
自动下单
Portfolio Management
Dashboard
多租户
```

第一阶段的原则：

> **Make operations visible, not complex.**

---

# 5. 系统边界

正确结构：

```text
                 BigA Core
                     │
                     ▼
               DecisionCard
                     │
            ┌────────┴────────┐
            │                 │
            ▼                 ▼
          Store         Notification Event
                              │
                              ▼
                       NotificationSink
                              │
                              ▼
                         FeishuSink
                              │
                              ▼
                            飞书
```

Inbound：

```text
飞书消息
   │
   ▼
Feishu Event Endpoint
   │
   ▼
FeishuCommandParser
   │
   ▼
BigATrigger
   │
   ▼
BigA Runner
```

---

# 6. 强制架构原则

## 6.1 Agent 不得直接调用飞书

禁止：

```text
Market Agent
    ↓
Feishu API
```

禁止：

```text
Risk Agent
    ↓
Feishu API
```

Agent 只产生：

```text
Evidence
AgentVerdict
DecisionCard
```

飞书发送属于外围 Adapter。

---

## 6.2 Feishu Adapter 不得修改决策

禁止：

```text
DecisionCard
   ↓
Feishu Adapter
   ↓
修改 stance / missing / summary
```

Feishu Adapter 只负责：

```text
format
render
send
```

核心 DecisionCard 必须保持原样。

---

## 6.3 通知失败不能破坏 Decision

正确行为：

```text
Decision 成功
Feishu 失败
```

最终仍然：

```text
Decision = COMPLETED
Notification = FAILED
```

不能：

```text
Feishu API timeout
    ↓
Decision rollback
```

通知是 Side Effect，不是 Decision transaction 的组成部分。

---

# 7. 推荐模块结构

建议新增：

```text
integrations/
└── feishu/
    ├── __init__.py
    ├── config.py
    ├── client.py
    ├── formatter.py
    ├── commands.py
    ├── inbound.py
    ├── outbound.py
    ├── security.py
    └── models.py
```

如果当前 repo 更偏向 Skill 风格，也可以放：

```text
skills/
└── feishu-notify/
```

但从职责上看更推荐：

```text
integrations/
```

原因：

```text
Feishu != deterministic skill
Feishu != specialist agent
Feishu == external adapter
```

---

# 8. 通用通知接口

建议不要让 BigA Core 依赖 Feishu 类。

定义通用接口：

```python
class NotificationSink:
    def publish_decision(self, card):
        ...

    def publish_failure(self, event):
        ...

    def publish_status(self, status):
        ...
```

实现：

```text
ConsoleSink
FeishuSink
```

未来可以增加：

```text
SlackSink
TelegramSink
DiscordSink
EmailSink
WebSink
```

BigA Core 只知道：

```text
NotificationSink
```

不知道飞书。

---

# 9. Outbound Event Model

不要直接把 DecisionCard JSON 塞给 Feishu。

建议增加 presentation event：

```python
NotificationEvent
```

示例：

```json
{
  "event_id": "notify_01",
  "event_type": "decision.completed",
  "decision_id": "BIGA-20260921-001",
  "created_at": "2026-09-21T15:00:00+08:00",
  "severity": "INFO",
  "payload_ref": "BIGA-20260921-001"
}
```

其他类型：

```text
decision.completed
decision.unknown
decision.blocked
decision.failed

agent.failed
provider.failed
runtime.spawn_failed

system.warning
system.health
```

---

# 10. 为什么使用 Notification Event

如果 BigA Core 直接：

```python
feishu.send(card)
```

未来会逐渐出现：

```text
Market 自己发
Risk 自己发
Supervisor 自己发
Provider 自己发
```

最终通知逻辑散落。

采用：

```text
Domain Event
    ↓
Notification Dispatcher
    ↓
Sink
```

可以统一：

```text
消息格式
失败重试
幂等
审计
多渠道
```

---

# 11. Feishu Client

`client.py` 只负责：

```text
认证
HTTP request
发送消息
错误映射
超时
Retry-After
```

不负责：

```text
DecisionCard 业务逻辑
UNKNOWN 判断
Risk 解释
命令解析
```

建议 API：

```python
class FeishuClient:
    def send_text(self, receive_id, text):
        ...

    def send_card(self, receive_id, card):
        ...
```

具体飞书 API endpoint、token scope 与 card schema 在实现阶段必须以飞书开放平台最新官方文档为准。

---

# 12. 鉴权策略

推荐使用飞书企业自建应用 / Bot。

需要保存：

```text
FEISHU_APP_ID
FEISHU_APP_SECRET
```

禁止写入：

```text
repo
AGENTS.md
fixtures
logs
DecisionCard
```

推荐：

```text
Environment Variables
```

例如：

```bash
FEISHU_APP_ID=...
FEISHU_APP_SECRET=...
FEISHU_RECEIVE_ID=...
```

---

# 13. Secret 管理

第一版：

```text
.env / environment
```

但：

```text
.env
```

必须加入 `.gitignore`。

禁止日志输出：

```text
app_secret
access_token
event verification secret
signature secret
```

所有日志只允许：

```text
token_present=true
```

不能打印真实 token。

---

# 14. Token Cache

如果使用应用 Access Token：

```text
get token
   ↓
cache
   ↓
reuse before expiration
```

不要每发一条消息都重新获取 token。

建议：

```text
TokenCache
```

内部记录：

```text
token
expires_at
```

在：

```text
expires_at - safety_window
```

提前刷新。

---

# 15. Outbound 消息类型

第一阶段支持：

```text
Text
Simple Interactive Card
```

默认使用：

```text
Simple Card
```

因为 DecisionCard 结构天然适合卡片。

---

# 16. DecisionCard 飞书展示

建议卡片第一版：

```text
BigA Decision
BIGA-20260921-001

Status: HOLD
Risk: PASS

Market      PASS / POSITIVE
Emotion     PASS / NEUTRAL
Sector      UNKNOWN
News        PASS / POSITIVE
Technical   PASS / WEAK

Missing:
• sector.constituent_coverage

Latency:
83.4s

Generated:
2026-09-21 15:02
```

原则：

```text
手机 10 秒能读完
```

不要把完整 Evidence 全塞进去。

---

# 17. Card 展示层级

## Level 1

飞书消息显示：

```text
Decision
Agent Summary
Missing
Latency
Risk
```

## Level 2

未来可提供：

```text
decision_id
```

查询完整详情。

完整 Evidence 仍然以：

```text
Store / Replay
```

为 Source of Truth。

---

# 18. UNKNOWN 展示

UNKNOWN 不应该被弱化。

例如：

```text
Sector
UNKNOWN
```

必须同时展示：

```text
Missing:
sector.constituent_coverage
```

不能只显示：

```text
Sector: unavailable
```

飞书应该帮助强化 BigA 的：

```text
UNKNOWN != PASS
```

原则。

---

# 19. Failure 通知

建议严重级别：

```text
INFO
WARNING
ERROR
CRITICAL
```

第一版映射：

```text
Decision completed     INFO
UNKNOWN                WARNING
Provider failed        WARNING
Agent failed           ERROR
Risk blocked           WARNING
Runtime spawn failed   ERROR
Pipeline failed        CRITICAL
```

---

# 20. 通知降噪

禁止每个低级 warning 都发消息。

否则真实运行一天后飞书会被刷爆。

建议发送规则：

```text
Decision Final State
Agent hard failure
Provider hard failure
Runtime failure
Pipeline failure
```

普通内部 warning：

```text
只进 DB / log
```

---

# 21. 通知幂等

必须防止重复发送。

建议：

```text
notification_key =
event_type + decision_id + version
```

例如：

```text
decision.completed:BIGA-20260921-001:v1
```

发送成功后保存：

```text
notification_delivery
```

重复执行：

```text
already delivered
    ↓
skip
```

---

# 22. 建议 Store 表

新增：

```text
notification_events
notification_deliveries
```

## notification_events

```text
event_id
event_type
decision_id
severity
payload_json
created_at
```

## notification_deliveries

```text
delivery_id
event_id
channel
target
status
attempt_count
last_error
sent_at
created_at
updated_at
```

---

# 23. 为什么 Notification 要落库

为了回答：

```text
Decision 生成了没有？
通知事件生成了没有？
飞书发送成功没有？
是否重试过？
用户为什么没收到？
```

把：

```text
Decision
```

和：

```text
Delivery
```

分开。

---

# 24. Retry 策略

Feishu 发送失败时：

```text
网络 timeout
5xx
rate limit
```

允许重试。

第一版可以：

```text
attempt 1
5 sec
attempt 2
30 sec
attempt 3
120 sec
```

最多：

```text
3 次
```

避免无限重试。

---

# 25. 不应重试的错误

例如：

```text
invalid credential
invalid receive_id
permission denied
invalid payload
```

应：

```text
FAIL
```

并记录：

```text
last_error
```

不要不断重试。

---

# 26. Inbound 接入模式

飞书 Bot 收到消息事件后：

```text
Feishu
   ↓
HTTPS Endpoint
   ↓
Verify
   ↓
Deduplicate
   ↓
Parse
   ↓
Authorize
   ↓
Dispatch Command
```

Inbound 与 Outbound 必须分离。

---

# 27. MVP Command Grammar

第一版严格限制命令。

支持：

```text
/biga market
/biga <symbol>
/biga status <decision_id>
/biga help
```

例如：

```text
/biga 600519
```

不支持：

```text
帮我看看今天哪个好
你觉得现在应该买吗
把 Risk 绕过去
强制 BUY
```

避免把飞书变成一个自由 Prompt 注入入口。

---

# 28. Command Parser

`commands.py`：

```python
parse_command(text)
```

返回：

```python
BigACommand(
    type="RUN_SYMBOL",
    symbol="600519"
)
```

或者：

```python
BigACommand(
    type="STATUS",
    decision_id="BIGA-20260921-001"
)
```

不要直接把用户文本传给 Supervisor。

---

# 29. Command 白名单

第一版：

```text
HELP
RUN_MARKET
RUN_SYMBOL
STATUS
```

任何未识别命令：

```text
REJECT
```

而不是：

```text
fallback → LLM
```

这能减少：

```text
Prompt Injection
误触发
不可预测行为
```

---

# 30. 用户授权

MVP 建议采用简单 allowlist。

环境配置：

```text
FEISHU_ALLOWED_OPEN_IDS
```

只有 allowlist 用户允许触发：

```text
RUN
```

未授权用户：

```text
可以忽略
或只返回 help
```

---

# 31. 群聊策略

第一版建议：

```text
只允许指定私聊
或指定测试群
```

配置：

```text
FEISHU_ALLOWED_CHAT_IDS
```

这样测试阶段避免：

```text
任何群成员都能触发 BigA
```

---

# 32. Event 安全

Inbound 必须实现：

```text
事件验签 / 验证
事件去重
时间窗口检查
```

不要只因为请求来自公网 URL 就信任。

具体签名字段和事件验证流程必须在实现阶段按飞书开放平台最新文档实现。

---

# 33. Event 去重

飞书事件可能因为重试被重复发送。

必须保存：

```text
external_event_id
```

如果：

```text
event already processed
```

则：

```text
return success
skip command
```

避免：

```text
一次消息
→ 两个 Decision ID
```

---

# 34. Trigger Flow

建议完整流程：

```text
Feishu Message
      │
      ▼
Verify Event
      │
      ▼
Deduplicate
      │
      ▼
Authorize
      │
      ▼
Parse Command
      │
      ▼
Reserve Decision ID
      │
      ▼
Return ACK / RUNNING
      │
      ▼
Execute BigA
      │
      ▼
DecisionCard
      │
      ▼
Notification Event
      │
      ▼
Feishu Result
```

---

# 35. 不要同步等待完整 BigA

BigA 当前一次运行可能：

```text
几十秒
```

Inbound HTTP handler 不应该：

```text
收到飞书事件
    ↓
同步跑完整 BigA
    ↓
80 秒后返回
```

正确方式：

```text
Inbound
   ↓
validate
   ↓
enqueue / spawn runner
   ↓
快速 ACK
```

然后：

```text
BigA complete
   ↓
Outbound notification
```

---

# 36. 第一版异步实现

如果暂时不引入 Queue，可以使用当前单机架构：

```text
subprocess / local runner
```

例如：

```text
Inbound endpoint
    ↓
write trigger request
    ↓
launch BigA process
```

但必须记录：

```text
trigger_id
decision_id
pid / run_ref
status
```

---

# 37. 不要为了飞书引入 Redis

当前：

```text
单机
单用户
单写进程
```

第一版不建议引入：

```text
Redis
Celery
Kafka
RabbitMQ
```

除非真实并发运行证明需要。

坚持：

> Complexity must be earned.

---

# 38. Trigger Request Model

建议：

```json
{
  "trigger_id": "ft_001",
  "source": "feishu",
  "external_event_id": "...",
  "requested_by": "ou_xxx",
  "chat_id": "oc_xxx",
  "command": "RUN_SYMBOL",
  "symbol": "600519",
  "received_at": "2026-09-21T15:00:00+08:00"
}
```

---

# 39. Trigger Store

建议新增：

```text
external_triggers
```

字段：

```text
trigger_id
source
external_event_id
requested_by
chat_id
command
args_json
decision_id
status
error
created_at
started_at
finished_at
```

---

# 40. Decision Identity

Feishu Trigger 不创建自己独立的分析身份。

必须：

```text
trigger
   ↓
reserve Decision ID
   ↓
decision_id
```

之后：

```text
所有 Agent task_id
Risk task_id
DecisionCard.decision_id
```

全部继续使用同一个 ID。

飞书只记录：

```text
trigger_id → decision_id
```

---

# 41. Status 查询

`/biga status <decision_id>`

不要实时问 Agent。

直接查询：

```text
Store
```

返回：

```text
Decision ID
Status
Current Stage
Started At
Elapsed
Completed Agents
Missing
Error
```

如果已经完成：

```text
DecisionCard summary
```

---

# 42. Current Stage

建议 pipeline 写简单阶段状态：

```text
CREATED
STAGE1_RUNNING
STAGE1_COMPLETED
RISK_RUNNING
SYNTHESIZING
COMPLETED
FAILED
```

这样飞书可以真正作为运维入口。

---

# 43. Observability

飞书接入后应记录：

```text
trigger count
trigger success rate
notification success rate
notification latency
duplicate event count
unauthorized request count
Feishu API failure count
```

这些数据本身就是 Phase 2.5 的 Operational Metrics。

---

# 44. DecisionCard 消息模板

推荐：

```text
📊 BigA Decision
BIGA-20260921-001

Decision: HOLD
Risk: PASS

Market      PASS / POSITIVE
Emotion     PASS / NEUTRAL
Sector      UNKNOWN
News        PASS / POSITIVE
Technical   PASS / WEAK

⚠ Missing
sector.constituent_coverage

⏱ 83.4s
2026-09-21 15:02
```

不要显示：

```text
超长 reasoning
完整 Prompt
内部 chain-of-thought
Secret
Raw Provider JSON
```

---

# 45. Failure 消息模板

```text
⚠ BigA Run Failed

Decision:
BIGA-20260921-002

Stage:
NEWS

Error:
PROVIDER_TIMEOUT

Missing:
news.provider.timeout

Decision state:
FAILED

Timestamp:
2026-09-21 15:12
```

---

# 46. UNKNOWN 消息

UNKNOWN 不等于 Pipeline Failure。

例如：

```text
Decision completed
but Sector = UNKNOWN
```

消息仍然：

```text
Decision Completed
```

同时：

```text
Warnings:
Sector UNKNOWN
```

这是 BigA 核心语义。

---

# 47. Risk BLOCK

Risk BLOCK 也不是系统错误。

展示：

```text
Decision Completed
Risk = BLOCK
```

而不是：

```text
Execution Failed
```

必须区分：

```text
Business Outcome
vs
System Failure
```

---

# 48. Adapter 错误模型

建议：

```text
FeishuAuthError
FeishuRateLimitError
FeishuTimeoutError
FeishuPayloadError
FeishuPermissionError
FeishuServerError
```

不要统一：

```text
Exception("feishu failed")
```

---

# 49. 配置

建议：

```text
FEISHU_ENABLED=false

FEISHU_APP_ID
FEISHU_APP_SECRET

FEISHU_RECEIVE_ID
FEISHU_RECEIVE_ID_TYPE

FEISHU_ALLOWED_OPEN_IDS
FEISHU_ALLOWED_CHAT_IDS

FEISHU_REQUEST_TIMEOUT_SEC=5
FEISHU_MAX_RETRIES=3
```

默认：

```text
FEISHU_ENABLED=false
```

避免开发环境误发。

---

# 50. Dry Run

必须支持：

```text
FEISHU_DRY_RUN=true
```

Dry Run：

```text
format message
validate payload
store notification
```

但：

```text
不真正请求飞书
```

便于测试。

---

# 51. Fixtures

建议：

```text
tests/fixtures/feishu/
├── message_run_symbol.json
├── message_status.json
├── duplicate_event.json
├── unauthorized_user.json
├── decision_card.json
├── unknown_card.json
└── failed_run.json
```

---

# 52. 单元测试

## Config

```text
missing config
disabled mode
dry run
```

## Formatter

```text
PASS Card
UNKNOWN Card
BLOCK Card
FAILED run
```

## Command Parser

```text
/biga market
/biga 600519
/biga status ...
invalid command
```

## Security

```text
unauthorized user
unauthorized chat
invalid event verification
duplicate event
```

---

# 53. Client 测试

mock HTTP：

```text
200
401
403
429
500
timeout
invalid JSON
```

验证：

```text
retryable
non-retryable
error mapping
```

---

# 54. Delivery 幂等测试

同一个：

```text
decision.completed
BIGA-...001
```

调用两次：

```text
第一次 send
第二次 skip
```

验证：

```text
只发送一次
```

---

# 55. Trigger 幂等测试

同一个飞书 Event 重发两次：

```text
Event A
Event A
```

必须：

```text
只产生一个 trigger
只 reserve 一个 decision_id
```

这是非常重要的测试。

---

# 56. E2E Test — Outbound

```text
Fixture DecisionCard
    ↓
Notification Event
    ↓
Feishu Formatter
    ↓
Mock Client
    ↓
Delivery Record
```

验证：

```text
Card 内容
decision_id
UNKNOWN
missing
delivery status
```

---

# 57. E2E Test — Inbound

```text
Fixture Feishu Event
    ↓
Verify
    ↓
Dedup
    ↓
Parse
    ↓
Authorize
    ↓
Reserve Decision
    ↓
Fake Runner
    ↓
Notification
```

不连接真实 Market Provider。

---

# 58. Live Test

上线前只允许：

```text
测试 Bot
测试群
测试用户
```

验证：

```text
/biga market
```

产生：

```text
1 trigger
1 decision
正确 task_id
正确 Agent run
1 final notification
```

---

# 59. Failure-first Live Tests

主动测试：

```text
错误 receive_id
飞书 token 过期
飞书 API timeout
重复 event
非法用户
BigA Agent fail
Provider timeout
UNKNOWN
Risk BLOCK
```

确认：

```text
不会重复 Decision
不会污染 Decision
不会因为通知失败导致 Card 失败
```

---

# 60. OpenClaw 与飞书边界

飞书不应该成为新的 Agent Runtime。

正确：

```text
Feishu
  ↓
Trigger BigA
  ↓
OpenClaw Supervisor / Specialists
```

而不是：

```text
Feishu Bot
  ↓
直接让 LLM 自由运行
```

保持 runtime boundary 清晰。

---

# 61. Security Principle

Feishu Inbound 是新的外部输入面。

因此必须认为：

```text
所有用户输入都不可信
```

即使来自：

```text
自己的飞书账号
```

也必须通过：

```text
parse
validate
allowlist
```

而不是直接进入 Prompt。

---

# 62. Prompt Injection 防护

禁止：

```text
user_message
    ↓
Supervisor Prompt
```

第一版只允许：

```text
严格 Command Grammar
```

例如：

```text
/biga 600519
```

解析出：

```json
{
  "command": "RUN_SYMBOL",
  "symbol": "600519"
}
```

Supervisor 只得到结构化参数。

---

# 63. Audit

每一次飞书触发应可追踪：

```text
谁触发
哪个 chat
哪个 external event
什么时候
生成哪个 decision
最终状态
```

但避免存储不必要的完整聊天历史。

---

# 64. Privacy

第一版只存：

```text
Open ID / Chat ID
command
timestamp
```

不要存：

```text
用户完整个人信息
聊天上下文
联系人信息
```

遵循最小数据原则。

---

# 65. 实施阶段

建议分四步。

---

## Phase F0 — Outbound Only

目标：

```text
DecisionCard
    ↓
飞书
```

实现：

```text
FeishuClient
FeishuSink
Formatter
Delivery Store
Dry Run
```

不做 inbound。

这是最小风险版本。

---

## Phase F1 — Failure Notification

增加：

```text
UNKNOWN
Agent Failure
Provider Failure
Pipeline Failure
```

建立 notification event model。

---

## Phase F2 — Inbound Command

增加：

```text
/biga market
/biga <symbol>
```

要求：

```text
event verify
dedup
allowlist
trigger store
```

---

## Phase F3 — Status Query

增加：

```text
/biga status <decision_id>
```

作为手机运维入口。

---

# 66. 为什么先 Outbound

Outbound：

```text
BigA → Feishu
```

风险低。

Inbound：

```text
Feishu → BigA
```

会引入：

```text
身份
鉴权
Prompt Injection
重复事件
远程执行
公网 endpoint
```

因此必须后做。

---

# 67. Definition of Done — F0

```text
[ ] DecisionCard 可以发送到测试飞书
[ ] UNKNOWN 正确展示
[ ] Missing 正确展示
[ ] Risk BLOCK 正确展示
[ ] 飞书失败不影响 Decision
[ ] delivery 落库
[ ] retry 工作
[ ] 幂等工作
[ ] Dry Run 工作
```

---

# 68. Definition of Done — F2

```text
[ ] Feishu Event 验证
[ ] Event 去重
[ ] User allowlist
[ ] Chat allowlist
[ ] 严格 Command Parser
[ ] /biga market
[ ] /biga <symbol>
[ ] 一个事件只产生一个 decision_id
[ ] 快速 ACK
[ ] BigA 在 handler 外运行
```

---

# 69. Phase 2.5 Operational Metrics

飞书上线后，开始记录：

```text
Daily decisions
UNKNOWN rate
Agent failure rate
Provider failure rate
Notification success rate
Feishu trigger count
Duplicate event count
Latency P50
Latency P95
Cost per Decision
Risk BLOCK rate
```

---

# 70. 飞书如何帮助系统打磨

真实运行后飞书每天会暴露：

```text
哪个 Agent 经常 UNKNOWN
哪个 Provider 经常 timeout
哪个 Stage 最慢
什么时候 News stale
什么时候 Runtime spawn fail
Risk 是否经常 BLOCK
Card 是否太长
哪些信息真正有用
```

这些数据反过来决定后续 Roadmap。

---

# 71. 不应该因为飞书做的事情

飞书接入不应该推动：

```text
重构 BigA Core
更换 Contract
更换 Store
引入 Queue 集群
引入 PostgreSQL
重写 Supervisor
```

正确目标：

```text
薄 Adapter
少依赖
强边界
高可观测
```

---

# 72. 推荐代码实施顺序

```text
FEI-01
NotificationSink abstraction

FEI-02
Feishu config + secret handling

FEI-03
Feishu HTTP client

FEI-04
DecisionCard formatter

FEI-05
notification_events / deliveries

FEI-06
idempotent outbound delivery

FEI-07
Decision completed notification

FEI-08
failure / UNKNOWN notification

FEI-09
Inbound security + event dedup

FEI-10
Command parser

FEI-11
Trigger store

FEI-12
BigA trigger runner

FEI-13
Status query

FEI-14
Live operational metrics
```

---

# 73. Claude Code 执行建议

可以把本设计交给 Claude Code，并要求：

```text
Implement the Feishu integration incrementally.

Start with outbound-only F0.

Do not implement inbound commands until outbound delivery,
idempotency, retries, and tests are complete.

Rules:

1. Feishu must remain an adapter outside BigA core decision logic.
2. No Specialist Agent may call Feishu directly.
3. Notification failure must never invalidate a completed DecisionCard.
4. Do not pass raw Feishu user text into Supervisor prompts.
5. Inbound commands must use a strict parser and allowlist.
6. Every external event must be idempotent.
7. Every notification delivery must be auditable.
8. Do not introduce Redis/Celery/Kafka in the MVP.
9. FEISHU_ENABLED must default to false.
10. Secrets must come from environment variables.
11. Add focused tests after every implementation step.
12. Run the full pytest suite after each completed phase.
13. Do not perform unrelated refactors.
```

---

# 74. 推荐 Milestone

## Milestone 1

```text
BigA → 飞书
```

只推 DecisionCard。

## Milestone 2

```text
BigA failure → 飞书
```

## Milestone 3

```text
飞书 → BigA
```

严格命令。

## Milestone 4

```text
飞书 → BigA Status
```

到这里停止扩功能，进入连续真实使用。

---

# 75. 最终架构

```text
                         ┌───────────────┐
                         │    Feishu     │
                         └───────┬───────┘
                                 │
                    Inbound      │      Outbound
                                 │
                 ┌───────────────┴──────────────┐
                 │                              │
                 ▼                              ▲
          Feishu Adapter                 NotificationSink
                 │                              │
                 ▼                              │
          Command Parser                        │
                 │                              │
                 ▼                              │
           BigA Trigger                         │
                 │                              │
                 ▼                              │
          Reserve Decision ID                   │
                 │                              │
                 ▼                              │
             Supervisor                         │
                 │                              │
       ┌─────────┼─────────┐                    │
       ▼         ▼         ▼                    │
    Market    Sector     News ...                │
       │         │         │                    │
       └─────────┼─────────┘                    │
                 ▼                              │
          Frozen Evidence                       │
                 │                              │
                 ▼                              │
               Risk                             │
                 │                              │
                 ▼                              │
           DecisionCard ────────────────────────┘
                 │
                 ▼
               Store
```

---

# 76. 最终建议

飞书 MVP 的核心价值不是“让 BigA 看起来像一个产品”。

真正价值是：

> **让 BigA 更容易被每天真实使用。**

真实使用带来的：

```text
UNKNOWN
Provider failure
Agent failure
Latency
Cost
Duplicate runs
Decision identity
Temporal bugs
Notification failures
```

才是当前阶段最需要的数据。

因此建议路线：

```text
Phase 2 P1 Hardening
        ↓
Feishu F0 Outbound
        ↓
Failure Notification
        ↓
连续真实运行
        ↓
Feishu Inbound
        ↓
Operational Metrics
        ↓
Evaluation / Review
        ↓
Phase 3 Discipline
```

飞书应该帮助 BigA 变得：

```text
更常运行
更容易观察
更容易发现问题
更容易复盘
```

而不是让核心系统变得更复杂。
