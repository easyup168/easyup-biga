# EasyUp BigA Phase 2 Code Review & 修复执行清单

> Review Target: `phase2` branch snapshot  
> Project: `easyup168/easyup-biga`  
> Review Date: 2026-09-21  
> Status: **Integration / Hardening**  
> Recommendation: **P1 修复完成前不建议合并到 `main`**

---

# 1. Review 摘要

本次 Review 针对上传的 `easyup-biga-phase2` 分支快照进行代码级审查，重点覆盖：

- Contract / DecisionCard 不变量
- Decision Identity / Evidence Identity
- Market / Sector / News / Technical / Risk Specialist
- Store 与 Verdict 持久化
- Replay
- OpenClaw Agent runtime 证明
- Phase 2 测试覆盖
- Phase 2 合并前的完整性风险

当前测试结果：

```text
445 tests collected
442 passed
3 skipped
0 failed
```

已有测试全部通过，说明当前已覆盖行为总体稳定。但 Review 发现若干测试尚未覆盖的**跨 Agent 一致性、时间语义和追溯性问题**。

当前阶段更准确的定位不是：

```text
Phase 2 Prototype
```

而是：

```text
Phase 2 Integration / Hardening
```

当前最重要的工作不应继续增加 Agent 或功能，而应优先钉死：

```text
Decision Identity
Evidence Identity
Stage Boundary
Temporal Semantics
Runtime Proof
```

---

# 2. 总体结论

Phase 2 主体架构已经基本成形。

目前已经具备：

```text
Supervisor
├── Emotion
├── Market
├── Sector
├── News
├── Technical
└── Risk
```

同时已经落地多项关键设计：

- Stage 0 Decision ID
- AgentVerdict 原件持久化
- MissingItem 机器码
- `stance` 与 `verdict` 分离
- Raw Hash
- Replay
- Failure-first testing
- OpenClaw runtime 验证思路
- UNKNOWN != PASS

当前最大的系统风险已经不再是：

> Agent 会不会乱说。

而是：

> 同一个 Decision 中的 Evidence / Verdict 是否真的属于同一次运行、同一个时间语义和同一份原始数据。

这是 Phase 2 从 Prompt 工程进入真正 Multi-Agent 一致性工程的标志。

---

# 3. Severity 定义

本 Review 使用以下优先级：

| Level | 含义 | 合并要求 |
|---|---|---|
| P0 | Blocker / 数据损坏 / 严重安全问题 | 必须立即修复 |
| P1 | High / 核心不变量可能被绕过 | **Phase 2 合并前必须修复** |
| P2 | Medium / 追溯性、可靠性、可维护性缺口 | 建议合并前修复 |
| P3 | Low / 风格、文档、长期维护优化 | 可后续处理 |

本次未发现 P0。

发现：

```text
P1 × 3
P2 × 3
```

---

# 4. P1-1 — DecisionCard 未强制 Verdict 属于同一个 Decision

## 4.1 问题

`synthesize.py` 已经检查：

```python
tids = {v.task_id for v in verdicts}

if len(tids) > 1:
    reject
```

该检查方向正确。

但真正的 `DecisionCard` Contract 没有强制：

```text
verdict.task_id == DecisionCard.decision_id
```

因此理论上可以构造：

```text
DecisionCard
decision_id = BIGA-20260921-001

Market Verdict
task_id = BIGA-20260921-999
```

并继续落库。

这意味着系统仍然可以表示：

```text
Card 001
    ↓
Verdict 999
```

这样的非法状态。

## 4.2 根因

关键业务不变量目前只存在于：

```text
CLI / orchestration layer
```

而没有下沉到：

```text
Contract layer
```

任何绕过 `synthesize.py` 的路径，包括：

```text
Replay
未来 API
测试辅助代码
手工构造
新的 orchestration
```

都可能重新打开这个漏洞。

## 4.3 修复建议

在：

```text
skills/_contract/card.py
```

的 `DecisionCard.__post_init__()` 增加硬约束：

```python
foreign = [
    verdict
    for verdict in self.verdicts
    if verdict.task_id != self.decision_id
]

if foreign:
    raise ValueError(
        "all verdict task_id values must match DecisionCard.decision_id"
    )
```

建议错误信息同时输出：

```text
decision_id
agent
verdict_id
foreign task_id
```

方便定位。

## 4.4 Regression Test

新增：

```text
test_card_rejects_foreign_task_verdict
```

测试至少覆盖：

```text
1. 全部 task_id 正确 → PASS
2. 一个 verdict task_id 不同 → reject
3. 多个 verdict 来自其他 decision → reject
```

## 4.5 验收

必须满足：

```text
非法 Card 无法构造
非法 Card 无法落库
Replay 也无法绕过
```

---

# 5. P1-2 — Risk 可混用不同 Decision 的 Stage 1 Verdict

## 5.1 问题

Risk 当前通过 `verdict_id` 加载 Stage 1 Verdict，并检查：

```text
Agent coverage
Trade date
Staleness
Threshold
Stance conflict
Cross-check
```

但没有强制：

```text
upstream_verdict.task_id == risk.task_id
```

因此可能出现：

```text
Market     BIGA-20260921-021
Emotion    BIGA-20260921-021
Sector     BIGA-20260921-020
News       BIGA-20260921-021
Technical  BIGA-20260921-019
```

Risk 仍可能看到：

```text
5 个 Specialist 全部存在
trade_date 相同
coverage_ratio = 1.0
```

但这些 Verdict 实际来自不同 Decision。

## 5.2 风险

这是典型的：

```text
Cross-run Evidence Contamination
```

最终 Card 即使有第二道防线，Risk 本身已经基于错误组合进行了判断。

因此最终拒绝 Card 并不能撤销：

```text
错误 Risk Verdict 已经生成
错误 Risk Verdict 可能已经落库
```

## 5.3 修复建议

在：

```text
skills/risk-check/scripts/risk_check.py
```

完成 upstream Verdict load 后立即验证：

```python
foreign = [
    verdict
    for verdict in upstream
    if verdict.task_id != task_id
]

if foreign:
    raise ValueError(...)
```

这里建议：

```text
FAIL CLOSED
```

而不是：

```text
missing[]
```

因为它不是数据缺失，而是执行身份错误。

## 5.4 不建议的处理

不要：

```text
把 foreign task_id 当 warning
继续 Risk 判断
```

也不要：

```text
转换为 UNKNOWN 后继续
```

正确行为应该是：

```text
停止本次 Risk run
记录 execution error
要求调用方重新提供正确 verdict refs
```

## 5.5 Regression Tests

新增：

```text
test_risk_rejects_mixed_task_ids
test_risk_rejects_upstream_task_id_not_equal_to_self
```

同时测试：

```text
相同 trade_date
不同 task_id
```

确保 trade date 不会掩盖 Decision Identity 错误。

---

# 6. P1-3 — News `as_of` 时间语义错误

## 6.1 问题

News 是：

```text
7x24 连续事件流
```

它没有传统日线意义上的：

```text
交易日收盘时间
```

但当前实现把最新 News 的日期转换为：

```text
trade_date
    ↓
as_of_for_trade_date()
    ↓
15:00
```

例如：

```text
retrieved_at = 20:00
latest news = 19:58
```

最终可能得到：

```text
as_of = 15:00
retrieved_at = 20:00
```

于是系统计算：

```text
staleness ≈ 5 hours
```

实际上最新消息只有：

```text
2 minutes
```

## 6.2 风险

这会污染：

```text
Evidence.staleness_sec
Risk max_staleness_sec
News freshness 判断
Card warning
后续数据质量统计
```

导致“新鲜新闻”被误判为“陈旧 Evidence”。

## 6.3 正确语义

对于 7x24 News：

```text
as_of = 最新消息真实 timestamp
retrieved_at = API 请求完成 timestamp
```

例如：

```text
as_of       = 2026-09-21T19:58:00+08:00
retrieved_at = 2026-09-21T20:00:03+08:00
```

这样：

```text
staleness ≈ 123 seconds
```

语义正确。

## 6.4 修复建议

在：

```text
skills/news-scan/scripts/news_scan.py
```

不要再对 News 调用：

```text
as_of_for_trade_date()
```

直接使用：

```python
latest_item_at = feed.items[0].at
```

作为 News Evidence 的 `as_of`。

如果某个字段代表整个窗口，例如：

```text
item_count
tag_counts
items
```

第一版可以统一采用：

```text
as_of = newest item timestamp
```

并在文档中明确这个定义。

## 6.5 Regression Tests

新增：

```text
test_news_as_of_uses_latest_item_timestamp
test_news_staleness_uses_event_time_not_market_close
```

关键 Case：

```text
retrieve = 20:00
latest item = 19:58

assert as_of == 19:58
assert staleness ≈ 120 sec
```

还应覆盖：

```text
跨午夜
周末
非交易日
盘前
盘后
```

因为 News 是 7x24 数据，不应受交易日 helper 影响。

---

# 7. P2-1 — News Raw Snapshot 已保存，但 Evidence 缺少 raw_hash

## 7.1 问题

News 已经保存 Raw Snapshot：

```text
save_raw_snapshot(...)
```

但从 News Raw 产生的 Evidence 没有完整携带：

```text
raw_hash
```

因此：

```text
item_count
quote_count
newest_at
tag_counts
items
```

无法直接追踪到：

> 究竟是哪一份 Provider Response 产生了这条 Evidence。

## 7.2 修复建议

保存 Raw Snapshot 后获取：

```text
payload_sha256
```

所有直接来自该 Raw Payload 的单源 Evidence 应带：

```text
raw_hash = payload_sha256
```

Derived Evidence 如果来自多份输入，可以：

```text
raw_hash = null
```

但必须通过：

```text
source
calc_version
upstream evidence refs
```

保持追溯。

## 7.3 测试建议

不要只测试 Market。

新增参数化 Traceability Test：

```text
all single-source non-derived Evidence
must have raw_hash
```

覆盖：

```text
Market
News
Sector
Technical
Emotion
```

如果某个领域有合理例外，应明确白名单，而不是默认放过。

---

# 8. P2-2 — `new_decision.py` 无法在全新 DB 上独立运行

## 8.1 问题

Stage 0 的：

```text
new_decision.py
```

直接调用：

```text
reserve_decision_id()
```

但底层读取 sequence 时使用 readonly connection。

当数据库尚不存在时，会出现：

```text
sqlite3.OperationalError:
unable to open database file
```

这意味着：

```text
new_decision.py
```

并不是一个真正自包含的 Stage 0 入口。

## 8.2 修复建议

在 CLI 入口中：

```python
db.init_schema()
decision_id = reserve_decision_id()
```

推荐把初始化放在：

```text
new_decision.py
```

而不是让低层 `reserve_decision_id()` 隐式执行 schema migration。

理由：

```text
Store primitive 应尽量保持职责清晰
CLI entrypoint 负责确保运行环境 ready
```

## 8.3 Regression Test

新增 subprocess 级测试：

```text
test_new_decision_works_on_fresh_db
```

流程：

```text
创建不存在的临时 DB path
    ↓
运行 new_decision.py
    ↓
assert exit code == 0
    ↓
assert DB created
    ↓
assert decision_id valid
```

---

# 9. P2-3 — `agent_runs` 语义与真实 Spawn Proof 不一致

## 9.1 问题

当前 Store / 注释中仍容易把：

```text
agent_runs
```

理解成：

> Specialist 确实被 Supervisor 调用的证明。

但 BigA 自己的业务代码可以写 `agent_runs`。

例如 synthesize 阶段也可以根据已有 Verdict 生成 ledger 记录。

因此：

```text
agent_runs != runtime spawn proof
```

## 9.2 正确语义

建议正式定义：

```text
agent_runs
=
BigA-side Verdict Execution Ledger
```

用于：

```text
哪个 Agent 参与
Verdict ID
开始/结束时间
状态
业务侧审计
```

而真正的：

```text
Agent Spawn Proof
```

必须来自业务代码无法伪造的外部 runtime：

```text
OpenClaw subagent_runs
```

## 9.3 修复建议

修改：

```text
db.py docstring
README
architecture docs
tutorial
verification script
```

统一语言。

不要再写：

```text
agent_runs 是唯一调用证明
```

改为：

```text
agent_runs 是 BigA 侧 execution ledger；
真实 spawn 必须由 OpenClaw runtime 记录交叉验证。
```

## 9.4 验收

Phase 2 E2E 验证应同时要求：

```text
BigA agent_runs exists
AND
OpenClaw subagent_runs exists
```

二者承担不同职责。

---

# 10. 本次 Review 中确认的优秀设计

以下部分建议保留，不要因为修复问题而重新设计。

## 10.1 Stage 0 Decision ID

正确链路：

```text
new_decision
    ↓
task_id
    ↓
所有 Specialist
    ↓
Risk
    ↓
DecisionCard
```

Decision Identity 在数据采集前建立，是正确方向。

---

## 10.2 Verdict 原件不通过 LLM 搬运

当前方向：

```text
Skill
 ↓
agent_verdicts DB
 ↓
verdict_ref
 ↓
Agent / Supervisor
```

优于：

```text
Skill JSON
 ↓
LLM copy
 ↓
LLM copy
 ↓
Card
```

这是重要的数据完整性设计。

---

## 10.3 MissingItem 机器码

使用：

```text
code
detail
```

而不是单纯自然语言 Missing。

未来可以直接统计：

```text
Provider 故障率
UNKNOWN 原因
缺失数据频率
Agent 数据质量
```

建议保持。

---

## 10.4 `stance` 与 `verdict` 分离

正确语义：

```text
verdict = 数据是否足够、判断是否有效
stance  = 当前判断方向
```

例如：

```text
PASS + WEAK
```

完全合法。

不要把：

```text
PASS
```

解释成正面观点。

---

## 10.5 Failure-first Engineering

当前代码已经体现：

```text
真实事故
    ↓
新增 invariant
    ↓
新增 regression test
```

这非常适合 BigA。

建议继续坚持：

> 每一个线上或 Live Run 事故，最终都应变成一个不可回退的测试。

---

# 11. Claude Code 逐条执行修复清单

下面的清单按执行顺序设计。

不要同时大范围重构。

原则：

```text
One invariant
    ↓
One implementation change
    ↓
Regression tests
    ↓
Full test suite
    ↓
Next invariant
```

---

## FIX-01 — DecisionCard Decision Identity Hard Guard

**Priority:** P1  
**Merge blocker:** YES

### 修改目标

```text
skills/_contract/card.py
```

### 任务

- [ ] 在 `DecisionCard.__post_init__()` 中检查所有 Verdict 的 `task_id`
- [ ] 强制 `verdict.task_id == self.decision_id`
- [ ] 发现 foreign Verdict 时抛出 `ValueError`
- [ ] 错误信息包含 `decision_id / verdict_id / agent / task_id`
- [ ] 不允许 Store 层保存非法 Card

### 测试

- [ ] `test_card_rejects_foreign_task_verdict`
- [ ] same decision → pass
- [ ] one foreign verdict → reject
- [ ] multiple foreign verdicts → reject

### 验证

```bash
pytest -q
```

必须：

```text
0 failed
```

---

## FIX-02 — Risk Stage Boundary Identity Guard

**Priority:** P1  
**Merge blocker:** YES

### 修改目标

```text
skills/risk-check/scripts/risk_check.py
```

### 任务

- [ ] load upstream Verdict 后立即校验 `task_id`
- [ ] 所有 upstream Verdict 必须等于本次 Risk `task_id`
- [ ] mixed task IDs 时 fail closed
- [ ] 不把 identity error 降级成 warning
- [ ] 不继续生成正常 Risk Verdict

### 测试

- [ ] `test_risk_rejects_mixed_task_ids`
- [ ] `test_risk_rejects_upstream_task_id_not_equal_to_self`
- [ ] same trade_date + different task_id 仍必须 reject

### 验证

```bash
pytest -q
```

---

## FIX-03 — Correct News Temporal Semantics

**Priority:** P1  
**Merge blocker:** YES

### 修改目标

```text
skills/news-scan/scripts/news_scan.py
```

### 任务

- [ ] 移除 News 对 `as_of_for_trade_date()` 的依赖
- [ ] News Evidence `as_of` 使用最新 item 的真实 timestamp
- [ ] `retrieved_at` 保持 API retrieval completion time
- [ ] 明确窗口统计 Evidence 的 `as_of` 定义
- [ ] 不让 News freshness 依赖交易日 15:00

### 测试

- [ ] `test_news_as_of_uses_latest_item_timestamp`
- [ ] `test_news_staleness_uses_event_time_not_market_close`
- [ ] 盘后 Case
- [ ] 盘前 Case
- [ ] 周末 Case
- [ ] 跨午夜 Case

### 验证

检查：

```text
20:00 retrieve
19:58 latest news
```

必须得到：

```text
staleness ≈ 2 minutes
```

而不是：

```text
≈ 5 hours
```

---

## FIX-04 — Complete News raw_hash Traceability

**Priority:** P2  
**Merge blocker:** Recommended

### 修改目标

```text
skills/news-scan/scripts/news_scan.py
tests/test_stance_and_traceability.py
```

### 任务

- [ ] 保存 Raw Snapshot 后取得 payload SHA-256
- [ ] 所有单源 News Evidence 写入 `raw_hash`
- [ ] 确认 `raw_hash` 与实际 Raw Snapshot payload 对应
- [ ] 不为 Derived/Multi-source Evidence 伪造单一 raw_hash

### 测试

- [ ] News single-source Evidence raw_hash 非空
- [ ] hash 与 Raw Snapshot 一致
- [ ] 扩展 Traceability test 到其他 Specialist

---

## FIX-05 — Make Stage 0 Work on Fresh DB

**Priority:** P2  
**Merge blocker:** Recommended

### 修改目标

```text
skills/decision-card/scripts/new_decision.py
```

### 任务

- [ ] CLI 启动时调用 `db.init_schema()`
- [ ] 再执行 `reserve_decision_id()`
- [ ] 不要求用户先运行其他脚本创建 DB
- [ ] 保持重复执行安全

### 测试

- [ ] `test_new_decision_works_on_fresh_db`
- [ ] 使用全新临时路径
- [ ] subprocess 执行 CLI
- [ ] exit code = 0
- [ ] DB 创建成功
- [ ] ID 格式正确

---

## FIX-06 — Clarify agent_runs vs Runtime Spawn Proof

**Priority:** P2  
**Merge blocker:** NO

### 修改目标

搜索：

```text
agent_runs
唯一凭证
spawn proof
Supervisor 确实调用
```

### 任务

- [ ] 修改 `_store/db.py` docstring
- [ ] 修改相关 README / architecture / tutorial
- [ ] 将 `agent_runs` 定义为 BigA execution ledger
- [ ] 将 OpenClaw `subagent_runs` 定义为 runtime spawn proof
- [ ] E2E verification 同时检查二者

### 验收

文档中不再存在：

```text
agent_runs alone proves real spawn
```

这样的表述。

---

# 12. 修复后的测试策略

P1/P2 修改完成后，不应只运行新增测试。

执行：

```bash
pytest -q
```

要求：

```text
all existing tests pass
all new regression tests pass
```

建议测试数量至少增加：

```text
+ 8 ~ 12 regression cases
```

重点不是测试数量，而是每一个 Review Finding 都必须有自动化防回退测试。

---

# 13. Live E2E 验证清单

Unit Test 全绿之后执行一次真实 Phase 2 Live Run。

建议验证：

```text
[ ] Stage 0 成功生成 decision_id

[ ] Market task_id == decision_id
[ ] Emotion task_id == decision_id
[ ] Sector task_id == decision_id
[ ] News task_id == decision_id
[ ] Technical task_id == decision_id

[ ] Risk task_id == decision_id

[ ] Risk upstream Verdict 全部属于同一 decision_id

[ ] DecisionCard.decision_id == 所有 Verdict.task_id

[ ] News as_of 是真实 News timestamp

[ ] News staleness 符合实际消息年龄

[ ] 单源 Evidence 有 raw_hash

[ ] BigA agent_runs 完整

[ ] OpenClaw subagent_runs 可证明真实 spawn

[ ] Card 成功落库

[ ] Replay 不重新 fetch

[ ] Replay 使用原 Frozen Evidence / Verdict

[ ] UNKNOWN / missing 行为仍正确
```

---

# 14. Phase 2 Merge Gate

建议建立明确 Merge Gate。

## 必须完成

```text
P1-1 DecisionCard identity
P1-2 Risk identity
P1-3 News temporal semantics
```

## 强烈建议完成

```text
P2-1 News raw_hash
P2-2 Fresh DB Stage 0
P2-3 agent_runs semantics
```

## 最终 Merge 条件

```text
[ ] 所有 P1 已关闭
[ ] P1 全部有 regression tests
[ ] pytest 全绿
[ ] Live E2E 全绿
[ ] 无 mixed decision identity
[ ] News 时间语义正确
[ ] Runtime spawn proof 验证通过
[ ] Replay 验证通过
```

满足后再考虑：

```text
phase2
  ↓
main
```

---

# 15. 不建议在本轮做的事情

Hardening 阶段不要顺手进行大范围架构重构。

暂时不要：

```text
重写 Store
更换 SQLite
重写 Contract 系统
更换 Agent Runtime
引入 PostgreSQL
重新设计全部目录
增加 Discipline Agent
增加更多市场指标
增加更多 Provider
```

当前优先级应该是：

```text
Correctness
    ↓
Identity
    ↓
Traceability
    ↓
Temporal Semantics
    ↓
Runtime Verification
    ↓
Performance
    ↓
New Features
```

---

# 16. 推荐 Commit 拆分

为了方便 Review 和回滚，建议不要一个 Commit 修全部问题。

推荐：

```text
fix(contract): enforce decision identity in DecisionCard

fix(risk): reject mixed upstream decision ids

fix(news): use event timestamp for evidence as_of

fix(news): attach raw hash to source evidence

fix(decision): initialize schema before reserving id

docs(runtime): clarify agent_runs and spawn proof semantics
```

每个 Commit：

```text
implementation
+
对应 regression tests
```

这样后续定位问题更容易。

---

# 17. Claude Code 建议执行 Prompt

可以把下面任务直接交给 Claude Code：

```text
Review docs/review/2026-09-21-phase2-code-review.md.

Implement FIX-01 through FIX-06 strictly in order.

For each FIX:

1. Inspect the referenced implementation and existing tests before editing.
2. Make the smallest change that enforces the documented invariant.
3. Add regression tests that fail before the fix and pass afterward.
4. Run the focused tests.
5. Run the full pytest suite.
6. Do not proceed to the next FIX while tests are failing.
7. Do not perform unrelated refactors.
8. Preserve current public contracts unless the review explicitly requires changing them.
9. Keep UNKNOWN != PASS and fail-closed behavior intact.
10. Report changed files, tests added, and final pytest result after each FIX.

After FIX-01 through FIX-06 are complete, run the Phase 2 live verification workflow and report any remaining deviations from the review document.
```

---

# 18. 最终架构不变量

Phase 2 合并前建议正式把以下规则视为不可违反的不变量：

```text
UNKNOWN != PASS

Missing != Zero

Agent != Calculator

Evidence != Prompt Text

Supervisor != Data Source

Replay != Re-fetch

Risk != Re-analysis

Raw Data != Agent Input

LLM Output != Evidence

Agent Claim != Runtime Proof

Verdict.task_id == DecisionCard.decision_id

Risk.upstream.task_id == Risk.task_id

News.as_of == Event Time

Single-source Evidence → Raw Snapshot Traceability
```

其中新增的四条：

```text
Verdict.task_id == DecisionCard.decision_id
Risk.upstream.task_id == Risk.task_id
News.as_of == Event Time
Single-source Evidence → Raw Snapshot Traceability
```

应成为本轮 Hardening 的核心成果。

---

# 19. 最终建议

Phase 2 当前已经具备合并前 Hardening 的基础。

建议下一步严格按照：

```text
FIX-01
 ↓
FIX-02
 ↓
FIX-03
 ↓
FIX-04
 ↓
FIX-05
 ↓
FIX-06
 ↓
Full pytest
 ↓
Live E2E
 ↓
Phase 2 Merge Review
 ↓
main
```

推进。

本轮不需要继续扩功能。

真正应该证明的是：

> BigA 不仅能让多个 Agent 同时工作，而且能够证明它们使用的是同一次决策、同一套可信 Evidence 和正确的时间语义。

这将是 Phase 2 从“功能完成”进入“可可信合并”的关键一步。
